<?php
define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', 'https://yourdomian.com' );
define('STYLESHEETS_URL', '//yourdomian.com' );
date_default_timezone_set('Asia/Kolkata');

/*
 ini_set("display_errors","1");
error_reporting(E_ALL);   */

error_reporting(0);
return [
  'db' => [
    'name'    =>  'ENTER YOUR DATABASE NAME' ,
    'host'    =>  'localhost',
    'user'    =>  'ENTER YOUR DATABASE NAME' ,
    'pass'    =>  'ENTER YOUR DATABASE NAME' ,
    'charset' =>  'utf8mb4'
  ]
];

?>